let personagem;
let personagemY;
let velocidadePersonagem = 5;
let larguraPersonagem = 20;
let alturaPersonagem = 20;

let obstaculosCidade = [];
let obstaculosCampo = [];
let velocidadeObstaculo = 3;
let tamanhoObstaculo = 25;

let estadoJogo = 'jogando'; // 'jogando', 'ganhou', 'perdeu'

function setup() {
  createCanvas(600, 400);
  personagemY = height / 2;
  personagem = new Personagem(50, personagemY, larguraPersonagem, alturaPersonagem);

  // Criar alguns obstáculos iniciais na cidade
  for (let i = 0; i < 3; i++) {
    obstaculosCidade.push(new Obstaculo(random(50, width / 2 - 50), random(0, height), tamanhoObstaculo, 'carro'));
  }
  // Criar alguns obstáculos iniciais no campo
  for (let i = 0; i < 3; i++) {
    obstaculosCampo.push(new Obstaculo(random(width / 2 + 50, width - 50), random(0, height), tamanhoObstaculo, 'animal'));
  }
}

function draw() {
  background(220);

  // Desenhar a divisão entre cidade e campo
  stroke(0);
  line(width / 2, 0, width / 2, height);
  textAlign(CENTER, CENTER);
  noStroke();
  fill(100);
  text("Cidade", width * 0.25, 20);
  fill(0, 150, 0);
  text("Campo", width * 0.75, 20);

  if (estadoJogo === 'jogando') {
    personagem.exibir();
    personagem.mover();

    // Movimentar e exibir obstáculos da cidade
    for (let obs of obstaculosCidade) {
      obs.mover();
      obs.exibir();
      if (personagem.colide(obs)) {
        estadoJogo = 'perdeu';
      }
    }

    // Movimentar e exibir obstáculos do campo
    for (let obs of obstaculosCampo) {
      obs.mover();
      obs.exibir();
      if (personagem.colide(obs)) {
        estadoJogo = 'perdeu';
      }
    }

    // Chegou ao campo
    if (personagem.x > width - larguraPersonagem / 2) {
      estadoJogo = 'ganhou';
    }
  } else if (estadoJogo === 'ganhou') {
    fill(0, 200, 0);
    textSize(32);
    text("Você chegou ao Campo!", width / 2, height / 2);
  } else if (estadoJogo === 'perdeu') {
    fill(200, 0, 0);
    textSize(32);
    text("Você colidiu!", width / 2, height / 2);
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    personagem.vx = -velocidadePersonagem;
  } else if (keyCode === RIGHT_ARROW) {
    personagem.vx = velocidadePersonagem;
  }
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {
    personagem.vx = 0;
  }
}

class Personagem {
  constructor(x, y, largura, altura) {
    this.x = x;
    this.y = y;
    this.largura = largura;
    this.altura = altura;
    this.vx = 0;
  }

  exibir() {
    fill(0, 0, 255);
    rectMode(CENTER);
    rect(this.x, this.y, this.largura, this.altura);
  }

  mover() {
    this.x += this.vx;
    this.x = constrain(this.x, larguraPersonagem / 2, width - larguraPersonagem / 2);
  }

  colide(outro) {
    let dentroX = this.x + this.largura / 2 > outro.x - outro.tamanho / 2 &&
                  this.x - this.largura / 2 < outro.x + outro.tamanho / 2;
    let dentroY = this.y + this.altura / 2 > outro.y - outro.tamanho / 2 &&
                  this.y - this.altura / 2 < outro.y + outro.tamanho / 2;
    return dentroX && dentroY;
  }
}

class Obstaculo {
  constructor(x, y, tamanho, tipo) {
    this.x = x;
    this.y = y;
    this.tamanho = tamanho;
    this.tipo = tipo;
    this.vy = velocidadeObstaculo;
  }

  exibir() {
    fill(this.tipo === 'carro' ? color(150) : color(100, 50, 0));
    ellipse(this.x, this.y, this.tamanho);
    if (this.tipo === 'carro') {
      fill(255);
      ellipse(this.x - this.tamanho / 4, this.y + this.tamanho / 4, this.tamanho / 5);
      ellipse(this.x + this.tamanho / 4, this.y + this.tamanho / 4, this.tamanho / 5);
    }
  }

  mover() {
    this.y += this.vy;
    if (this.y > height + this.tamanho / 2) {
      this.y = -this.tamanho / 2;
      this.x = this.tipo === 'carro' ? random(50, width / 2 - 50) : random(width / 2 + 50, width - 50);
    }
  }
}